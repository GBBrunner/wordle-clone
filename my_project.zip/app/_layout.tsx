import {
  DarkTheme,
  DefaultTheme,
  ThemeProvider,
} from "@react-navigation/native";
import { Link, Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";

import { UserIcon } from "@/components/ui/user-icon";
import { Colors } from "@/constants/theme";
import { useAuth } from "@/hooks/use-auth";
import { useColorScheme } from "@/hooks/use-color-scheme";
import { Platform, Pressable, View } from "react-native";

// Removed anchor to tabs; focusing app on Wordle screen.

export default function RootLayout() {
  const colorScheme = useColorScheme();

  return (
    <ThemeProvider value={colorScheme === "dark" ? DarkTheme : DefaultTheme}>
      <Stack initialRouteName="index">
        <Stack.Screen
          name="index"
          options={{
            title: "Home",
            headerRight: () => <HeaderUserLink />,
          }}
        />
        <Stack.Screen
          name="wordle"
          options={{
            title: "Wordle",
            // Enable default back arrow to previous screen (Home)
            headerRight: () => <HeaderUserLink />,
          }}
        />
        <Stack.Screen
          name="dashboard"
          options={{
            title: "Dashboard",
            headerRight: () => <HeaderUserLink />,
          }}
        />
        <Stack.Screen
          name="login"
          options={{
            title: "Login",
            headerRight: () => <HeaderUserLink />,
          }}
        />
        <Stack.Screen
          name="modal"
          options={{ presentation: "modal", title: "Modal" }}
        />
      </Stack>
      <StatusBar style="auto" />
    </ThemeProvider>
  );
}

function HeaderUserLink() {
  const colorScheme = useColorScheme();
  const { signedIn, isClient } = useAuth();

  // Avoid hydration mismatch: render empty placeholder during SSR
  if (!isClient) {
    return <View style={{ width: 32, height: 32 }} />;
  }

  const href = signedIn ? "/dashboard" : "/login";
  if (Platform.OS === "web") {
    // Use a plain anchor on web to avoid RN touch event issues
    return (
      <Link href={href}>
        <UserIcon size={32} color={Colors[colorScheme ?? "light"].tint} />
      </Link>
    );
  }
  return (
    <Link href={href} asChild>
      <Pressable accessibilityRole="button" hitSlop={8}>
        <UserIcon size={32} color={Colors[colorScheme ?? "light"].tint} />
      </Pressable>
    </Link>
  );
}
