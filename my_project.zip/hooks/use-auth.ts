import { useCallback, useEffect, useState } from "react";

export function useAuth() {
  const [isClient, setIsClient] = useState(false);
  const [signedIn, setSignedIn] = useState<boolean | null>(null);

  // Mark that we're on the client to avoid hydration mismatch
  useEffect(() => {
    setIsClient(true);
  }, []);

  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/auth/me", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to get auth state");
      const data = (await res.json()) as { signedIn: boolean };
      setSignedIn(data.signedIn);
    } catch {
      setSignedIn(false);
    }
  }, []);

  useEffect(() => {
    if (isClient) {
      refresh();
    }
  }, [isClient, refresh]);

  return { signedIn, refresh, isClient };
}
